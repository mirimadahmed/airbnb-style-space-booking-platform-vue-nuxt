<template>
  <div class="m-5 p-4 text-left">
    <div class="row m-0">
      <div class="col-md-12">
        <h1 class="heading">About us</h1>
      </div>
      <div class="col-md-6 section-text">
        <p>Spacesly.com is an online platform which aims to reduce the hassle that takes place while creating memorable events. We do that by connecting you with trustworthy venues, which can be booked according to your budget and then decorated by your choice.</p>
        <p>
          Spacesly.com is aware that it takes weeks, if not months to choose a suitable venue in a feasible way, thus we are here to ease your troubles.
          Hosting a glorious wedding that requires a large hall, or a corporate meeting but don't have an auditorium? Maybe you're in charge of a football match that requires a sports stadium? We have all that and more. Browse through all the facilities available on our website, compare them, share ideas with others and then begin planning for the upcoming celebration!
          Turn your dreams into reality with us. The perfect event is just a click away.
        </p>
      </div>
      <div class="col-md-6">
        <img src="https://spacesly.s3.amazonaws.com/image0.jpeg" class="col-md-12" />
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>
