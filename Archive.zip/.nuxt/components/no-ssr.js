/*
** From https://github.com/egoist/vue-no-ssr
** With the authorization of @egoist
*/
import NoSsr from 'vue-no-ssr'
export default {
  ...NoSsr,
  name: 'NoSsr'
}
