<template>
  <a-skeleton active :paragraph="{rows: 4}" :title="false" />
</template>

<script>
export default {};
</script>
