import Lingallery from "lingallery";
import Vue from 'vue'
Vue.component('lingallery', Lingallery);
