import Vue from 'vue';
import Multiselect from 'vue-multiselect'

// register globally
Vue.component('multiselect', Multiselect)
