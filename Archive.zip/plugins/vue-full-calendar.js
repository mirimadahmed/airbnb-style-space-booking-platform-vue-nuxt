import Vue from 'vue';
import VueFullCalendar from 'vue-full-calendar';

Vue.use(VueFullCalendar);
